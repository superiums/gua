const config = {
    siteName: '推卦盘',
    description: '周易六十四卦',
    cardBackgroundColor: '#333'

}

export default {
    config
}