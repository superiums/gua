module.exports = {
    "transpileDependencies": [
        "vuetify"
    ],
    publicPath: './',
    outputDir: '../www-tuiguapan/',
    assetsDir: '',
    indexPath: 'index.html',
    filenameHashing: process.env.NODE_ENV === 'production' ? 'false' : 'true',

}